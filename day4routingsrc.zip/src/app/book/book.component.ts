import { Component, OnDestroy, OnInit } from '@angular/core';

@Component({
  selector: 'app-book',
  template: `
    <h1>Books</h1>
    <table border="1">
      <tr>
        <td>1</td><td><a routerLink="1">Ignited Minds</a></td>
      </tr>
      <tr>
      <td>2</td><td><a routerLink="2">Harry Potter</a></td>
      </tr>
    </table>
  `,
  styles: [
  ]
})
export class BookComponent implements OnInit, OnDestroy {

  constructor() { }

  ngOnInit(): void {
    console.log('oninit')
  }

  ngOnDestroy(): void {
    console.log('ondestroy')
  }

  ngDoCheck(){
    
  }
}
