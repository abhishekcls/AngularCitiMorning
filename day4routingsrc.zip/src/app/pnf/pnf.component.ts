import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pnf',
  template: `
    <h1 style="color: red">404: NOT Found</h1>
  `,
  styles: [
  ]
})
export class PnfComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
