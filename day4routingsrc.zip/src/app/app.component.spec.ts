import { AppComponent } from "./app.component"

describe('addition',()=>{
  it('+ves',()=>{
    let app=new AppComponent();
     expect(app.add(2,3)).toBe(5);
  })
  it('-ves',()=>{
    let app=new AppComponent();
     expect(app.add(-2,-3)).toBe(-5);
  })
})