import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-userdetail',
  templateUrl: './userdetail.component.html',
  styleUrls: ['./userdetail.component.css']
})
export class UserdetailComponent implements OnInit {
  user:any;
  id:string;
  constructor(us:UserService,ar:ActivatedRoute) { 
    this.id=ar.snapshot.params["id"];
    us.getUserbyID(this.id).subscribe(u=>this.user=u);
  }

  ngOnInit(): void {
  }

}
