import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-bookdetail',
  template: `
    <p>
      bookdetail of {{id}}
    </p>
    <button (click)="back()">Back</button>
  `,
  styles: [
  ]
})
export class BookdetailComponent implements OnInit {
  id:string
  constructor(ar:ActivatedRoute,private r:Router) { 
    this.id=ar.snapshot.params["bid"];
  }

  ngOnInit(): void {
  }

  back(){
    this.r.navigate(['/book']);
  }
}
