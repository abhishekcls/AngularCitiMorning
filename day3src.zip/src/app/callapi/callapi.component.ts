import { Component, OnInit } from '@angular/core';
import { UserapiService } from '../userapi.service';

@Component({
  selector: 'app-callapi',
  template: `
    <p>
      callapi works!
    </p>
  `,
  styles: [
  ]
})
export class CallapiComponent implements OnInit {

  constructor(us:UserapiService)//DI
   {
    us.getUsers().subscribe(users=>console.log(users));
  }

  ngOnInit(): void {
  }

}
