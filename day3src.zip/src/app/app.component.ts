import { Component } from "@angular/core";

@Component({
    selector:'app',
    template:`<h1>Angular14 App by {{name}}</h1>
    <app-callapi></app-callapi>
    <app-rform></app-rform>
    <app-misc2></app-misc2>
    <app-tform></app-tform>
    {{games}}
    <ol>
        <li *ngFor="let g of games">
            {{g}}
        </li>
    </ol>
    {{emp.eid + " "+ emp.ename}}
    {{emp.eid}} {{emp.ename}}
    {{emp | json}}
    <table border="1">
        <tr *ngFor="let e of emps">
            <td>{{e.eid}}</td>
            <td>{{e.ename}}</td>
            <td>{{e.ename | uppercase}}</td>
            <td>{{e.ename | lowercase}}</td>
            <td>{{e.ename | slice:2 | uppercase}}</td>
            <td>{{e.ename | slice:2:4}}</td>
            <td>{{e.gender | gender}}</td>
            <td>{{e.sal}}
                <span *ngIf="e.sal>70000">*</span>
                <span *ngIf="checkSal(e.sal)">#</span>
            </td>
            <td>{{e.sal | number}}</td>
            <td>{{e.sal | currency}}</td>
            <td>{{e.sal | currency:'EUR'}}</td>
            <td>{{e.sal | currency:"INR"}}</td>
            <td>{{e.sal | tax | currency:"INR"}}</td>
            <td>{{e.sal | tax:0.2}}</td>
            <td>{{e.retired}}</td>
            <td>{{e.doj | date}}</td>
            <td>{{e.doj | date:'d/MMM/y'}}</td>
            <td>        
                <img *ngIf="e.retired; else working" src="https://i.pinimg.com/originals/0e/3e/e5/0e3ee551876e1ad2a39f89e4adf9168a.gif" height="100" width="100"/>
                <!-- <img *ngIf="!e.retired" src="https://acegif.com/wp-content/uploads/2022/4hv9xm/crying-emoji-7.gif" height="100" width="100"/> -->
                <ng-template #working>
                    <img src="https://acegif.com/wp-content/uploads/2022/4hv9xm/crying-emoji-7.gif" height="100" width="100"/>
                </ng-template>
            </td>
        </tr>
    </table>

    <nested></nested>`,
    styles:[`
    h1{
        color:red
    }
    `]
})
export class AppComponent{
    name:string
    games:string[]=['hockey','cricket','polo']
    emp={'eid':101,'ename':'Tarun'}
    emps=[
        {'eid':1101,'ename':'Ravi','gender':'M','sal':55000,'retired':false,'doj':new Date("2011-01-04")},
        {'eid':1102,'ename':'Kavita','gender':'F','sal':75000,'retired':false,'doj':new Date("2015-04-08")},
        {'eid':1103,'ename':'Tarun','gender':'M','sal':90000,'retired':true,'doj':new Date("1990-11-11")},
        {'eid':1104,'ename':'Shivam','gender':'M','sal':45000,'retired':false,'doj':new Date("2015-07-08")},
        {'eid':1105,'ename':'Priya','gender':'F','sal':85000,'retired':true,'doj':new Date("1992-02-03")}
    ]
    constructor(){
        this.name="Abhishek Samanta"
    }
    checkSal(sal:number):boolean{
        return sal>70000;
    }
}