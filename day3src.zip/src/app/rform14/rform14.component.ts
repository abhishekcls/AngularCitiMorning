import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-rform14',
  templateUrl: './rform14.component.html',
  styleUrls: ['./rform14.component.css']
})
export class Rform14Component implements OnInit {

  emprForm14:FormGroup=new FormGroup({
    eid:new FormControl<string|null>('abc'),
    ename:new FormControl<string|null>(null)
  });

  show(){
    
  }
  constructor() { }

  ngOnInit(): void {
    //console.log(this.emprForm14.value.)
  }

}
