import { Component } from "@angular/core";

@Component({
    selector:'nested',
    template:'<h2>Nested</h2>'
})
export class NestedComponent{}