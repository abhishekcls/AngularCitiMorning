export class customValidators{
    static eidValidator(c:any){
        if(!c.value){
          return null
        }
    
        let min=101,max=135;
        let eid=c.value;
    
        if(eid>=min && eid<=max){
          return null
        }
        else
          return {'veid':{'min':min,'max':max}};
      }
}