import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { customValidators } from '../customValidators';

@Component({
  selector: 'app-rform',
  templateUrl: './rform.component.html',
  styleUrls: ['./rform.component.css']
})
export class RformComponent implements OnInit {
emprForm:FormGroup;
  /*emprForm:FormGroup=new FormGroup({
    eid:new FormControl('',this.eidValidator),
    ename:new FormControl('',Validators.compose([
      Validators.required,
      Validators.pattern('[a-zA-Z]{2,10}')
    ]))
  });*/
  
  constructor(fb:FormBuilder) //DI
  { 
    this.emprForm=fb.group({eid:[1,customValidators.eidValidator],ename:['abc',Validators.required]});
  }

  ngOnInit(): void {
  }

  onSubmit(data:any){
    console.log(data);
  }

  setValue(){
    this.emprForm.setValue({eid:101,ename:'Abhishek'});
  }

  patchValue(){
    this.emprForm.patchValue({ename:'Gaurav'});
  }

  
}
