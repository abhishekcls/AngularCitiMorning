import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { AnotherComponent } from "./another.component";
import { AppComponent } from "./app.component";
import { GenderPipe } from "./gender.pipe";
import { NestedComponent } from "./nested.component";
import { TaxPipe } from "./tax.pipe";
import { TformComponent } from './tform/tform.component';
import { MiscComponent } from './misc/misc.component';
import { Misc2Component } from './misc2/misc2.component';
import { RformComponent } from './rform/rform.component';
import { Rform14Component } from './rform14/rform14.component';
import {HttpClientModule} from '@angular/common/http';
import { CallapiComponent } from './callapi/callapi.component'; 
import { UserapiService } from "./userapi.service";

@NgModule({
    imports:[BrowserModule,FormsModule,ReactiveFormsModule,HttpClientModule],
    declarations:[AppComponent,AnotherComponent,NestedComponent,
        GenderPipe,TaxPipe, TformComponent, MiscComponent, Misc2Component, RformComponent, Rform14Component, CallapiComponent],
    bootstrap:[AppComponent,AnotherComponent],
    providers:[UserapiService]
})
export class AppModule{}