import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Misc2Component } from './misc2.component';

describe('Misc2Component', () => {
  let component: Misc2Component;
  let fixture: ComponentFixture<Misc2Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ Misc2Component ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Misc2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
