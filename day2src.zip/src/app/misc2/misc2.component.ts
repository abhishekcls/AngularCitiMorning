import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-misc2',
  template: `
  <h1>Misc</h1>
  <button (click)="show()" disabled="{{flag}}">click1</button>
  <button (click)="show()" [disabled]="flag">click2</button>

  <button on-click="show()" bind-disabled="flag">click2 canonical</button>

  <button on-click="show()">click canonical</button>

  <img src="{{path}}"/>
  <img [src]="path"/>

  <img bind-src="path"/>

  <img src="{{basepath}}lol.gif"/>
  <img src="{{basepath}}cry.gif"/>
  `,
  styles: [
  ]
})
export class Misc2Component implements OnInit {
  flag:boolean=false;

  path:string="https://hdsmileys.com/wp-content/uploads/2017/11/blush.gif"

  basepath:string="https://hdsmileys.com/wp-content/uploads/2017/11/"
  constructor() { }

  ngOnInit(): void {
  }
  show(){
    alert('hello')
  }
}
