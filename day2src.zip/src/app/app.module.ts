import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { BrowserModule } from "@angular/platform-browser";
import { AnotherComponent } from "./another.component";
import { AppComponent } from "./app.component";
import { GenderPipe } from "./gender.pipe";
import { NestedComponent } from "./nested.component";
import { TaxPipe } from "./tax.pipe";
import { TformComponent } from './tform/tform.component';
import { MiscComponent } from './misc/misc.component';
import { Misc2Component } from './misc2/misc2.component';

@NgModule({
    imports:[BrowserModule,FormsModule],
    declarations:[AppComponent,AnotherComponent,NestedComponent,
        GenderPipe,TaxPipe, TformComponent, MiscComponent, Misc2Component],
    bootstrap:[AppComponent,AnotherComponent]
})
export class AppModule{}