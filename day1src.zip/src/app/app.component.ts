import { Component } from "@angular/core";

@Component({
    selector:'app',
    template:`<h1>Angular14 App by {{name}}</h1>
    {{games}}
    <ol>
        <li *ngFor="let g of games">
            {{g}}
        </li>
    </ol>
    {{emp.eid + " "+ emp.ename}}
    {{emp.eid}} {{emp.ename}}
    <nested></nested>`,
    styles:[`
    h1{
        color:red
    }
    `]
})
export class AppComponent{
    name:string
    games:string[]=['hockey','cricket','polo']
    emp={'eid':101,'ename':'Tarun'}
    constructor(){
        this.name="Abhishek Samanta"
    }
}