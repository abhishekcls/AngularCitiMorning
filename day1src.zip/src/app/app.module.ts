import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";
import { AnotherComponent } from "./another.component";
import { AppComponent } from "./app.component";
import { NestedComponent } from "./nested.component";

@NgModule({
    imports:[BrowserModule],
    declarations:[AppComponent,AnotherComponent,NestedComponent],
    bootstrap:[AppComponent,AnotherComponent]
})
export class AppModule{}