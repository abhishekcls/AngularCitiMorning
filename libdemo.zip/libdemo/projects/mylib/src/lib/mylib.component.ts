import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'lib-mylib',
  template: `
    <h1>MyLib Library</h1>
    <button (click)="show()">click</button>
  `,
  styles: [
  ]
})
export class MylibComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  show(){
    alert('Hello from Abhishek\'s mylib library')
  }
}
