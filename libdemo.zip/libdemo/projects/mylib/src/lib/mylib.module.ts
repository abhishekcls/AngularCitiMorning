import { NgModule } from '@angular/core';
import { MylibComponent } from './mylib.component';



@NgModule({
  declarations: [
    MylibComponent
  ],
  imports: [
  ],
  exports: [
    MylibComponent
  ]
})
export class MylibModule { }
